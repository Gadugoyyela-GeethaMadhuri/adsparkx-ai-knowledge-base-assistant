import json
import os
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv
from google import genai
from google.genai import types
import chromadb
from chromadb.config import Settings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from pypdf import PdfReader

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
CHROMA_DIR = BASE_DIR / "chroma_db"

load_dotenv()

st.set_page_config(page_title="Persona-Adaptive Support Agent", page_icon="🤖", layout="wide")

SYSTEM_PERSONA_PROMPT = """You are a customer support agent. Choose exactly one persona from: Technical Expert, Frustrated User, Business Executive.
Return JSON with keys persona and justification.
Persona rules:
- Technical Expert: precise technical language, headers, parameters, logs, code-like details.
- Frustrated User: empathetic, simple, short bullets, acknowledge pain.
- Business Executive: concise, professional, impact/timeline oriented.
"""

RESPONSE_PROMPT = """You are a persona-adaptive customer support agent.
Use ONLY the provided context from the knowledge base.
Match the response style to the persona.
If the answer is not present in the context, say you could not find it in the knowledge base and recommend escalation.
Keep the answer grounded and practical.
"""

ESCALATION_KEYWORDS = ["refund", "duplicate charge", "billing", "legal", "account change", "cancel subscription", "dispute"]

@st.cache_resource
def get_client():
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        return None
    return genai.Client(api_key=api_key)

@st.cache_resource
def get_collection():
    client = chromadb.PersistentClient(path=str(CHROMA_DIR), settings=Settings(allow_reset=False))
    return client.get_or_create_collection(name="support_kb")


def read_file_text(path: Path) -> str:
    if path.suffix.lower() in {".txt", ".md"}:
        return path.read_text(encoding="utf-8", errors="ignore")
    if path.suffix.lower() == ".pdf":
        reader = PdfReader(str(path))
        return "\\n".join(page.extract_text() or "" for page in reader.pages)
    return ""


def embed_text(client, text: str):
    result = client.models.embed_content(
        model="text-embedding-004",
        contents=text,
    )
    return result.embeddings[0].values


def ingest_documents(force=False):
    client = get_client()
    collection = get_collection()
    if client is None:
        return False, "GEMINI_API_KEY not found."
    if force:
        try:
            collection.delete(where={})
        except Exception:
            pass
    splitter = RecursiveCharacterTextSplitter(chunk_size=700, chunk_overlap=100)
    docs = []
    for path in DATA_DIR.glob("*"):
        if path.suffix.lower() not in {".txt", ".md", ".pdf"}:
            continue
        raw = read_file_text(path).strip()
        if not raw:
            continue
        chunks = splitter.split_text(raw)
        for i, chunk in enumerate(chunks):
            docs.append((f"{path.name}::chunk{i}", chunk, {"source": path.name, "chunk": i}))
    if not docs:
        return False, "No documents found in data/."
    ids, texts, metas, embs = [], [], [], []
    for doc_id, text, meta in docs:
        ids.append(doc_id)
        texts.append(text)
        metas.append(meta)
        embs.append(embed_text(client, text))
    collection.upsert(ids=ids, documents=texts, metadatas=metas, embeddings=embs)
    return True, f"Indexed {len(docs)} chunks from {len(list(DATA_DIR.glob('*')))} files."


def classify_persona(client, user_message: str):
    prompt = f"{SYSTEM_PERSONA_PROMPT}\\n\\nUser message: {user_message}\\nReturn only JSON."
    resp = client.models.generate_content(
        model="gemini-2.0-flash",
        contents=prompt,
        config=types.GenerateContentConfig(response_mime_type="application/json"),
    )
    text = resp.text.strip()
    try:
        data = json.loads(text)
    except Exception:
        data = {"persona": "Technical Expert", "justification": "Fallback classification because JSON parsing failed."}
    persona = data.get("persona", "Technical Expert")
    if persona not in {"Technical Expert", "Frustrated User", "Business Executive"}:
        persona = "Technical Expert"
    return {"persona": persona, "justification": data.get("justification", "")}


def retrieve_context(client, query: str, k=3):
    collection = get_collection()
    q_emb = embed_text(client, query)
    results = collection.query(query_embeddings=[q_emb], n_results=k)
    docs = results.get("documents", [[]])[0]
    metas = results.get("metadatas", [[]])[0]
    distances = results.get("distances", [[]])[0]
    items = []
    for d, m, dist in zip(docs, metas, distances):
        items.append({"text": d, "meta": m, "distance": dist})
    return items


def should_escalate(message: str, retrieved_items):
    msg = message.lower()
    if any(k in msg for k in ESCALATION_KEYWORDS):
        return True, "Sensitive billing/legal/account-related request detected."
    if not retrieved_items:
        return True, "No relevant knowledge base match found."
    if retrieved_items[0]["distance"] is not None and retrieved_items[0]["distance"] > 0.65:
        return True, "Retrieval confidence is low."
    return False, ""


def generate_response(client, persona, user_message, retrieved_items):
    context = "\\n\\n".join(
        f"Source: {item['meta'].get('source')}\\nContent: {item['text']}" for item in retrieved_items
    )
    prompt = f"{RESPONSE_PROMPT}\\n\\nPersona: {persona}\\n\\nContext:\\n{context}\\n\\nUser message: {user_message}"
    resp = client.models.generate_content(model="gemini-2.0-flash", contents=prompt)
    return resp.text


def generate_handoff(user_message, persona, reason, retrieved_items):
    return {
        "issue_summary": user_message,
        "persona": persona,
        "escalation_reason": reason,
        "retrieved_sources": [item["meta"].get("source") for item in retrieved_items],
        "recommended_action": "Assign to a human support specialist.",
    }


st.title("🤖 Persona-Adaptive Customer Support Agent")
st.caption("Builds persona-aware responses using Gemini + RAG + ChromaDB")

client = get_client()
if client is None:
    st.error("Add your GEMINI_API_KEY in a .env file before running the app.")
    st.stop()

col1, col2 = st.columns([1, 1])
with col1:
    if st.button("Index / Rebuild Knowledge Base"):
        ok, msg = ingest_documents(force=True)
        st.success(msg) if ok else st.error(msg)
with col2:
    st.write("Documents in data/:", len(list(DATA_DIR.glob('*'))))

user_message = st.text_area("Enter customer message", height=140, placeholder="Type a support query here...")

if st.button("Generate Response"):
    if not user_message.strip():
        st.warning("Please enter a message.")
        st.stop()
    with st.spinner("Analyzing..."):
        persona_info = classify_persona(client, user_message)
        retrieved = retrieve_context(client, user_message)
        escalate, reason = should_escalate(user_message, retrieved)
        st.subheader("Detected Persona")
        st.write(persona_info)
        st.subheader("Retrieved Context")
        st.json(retrieved)
        if escalate:
            handoff = generate_handoff(user_message, persona_info["persona"], reason, retrieved)
            st.error("Escalation triggered")
            st.json(handoff)
        else:
            answer = generate_response(client, persona_info["persona"], user_message, retrieved)
            st.subheader("Generated Response")
            st.write(answer)
