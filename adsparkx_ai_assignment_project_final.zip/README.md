# Persona-Adaptive Customer Support Agent

## What this project does
- Classifies the user's persona as Technical Expert, Frustrated User, or Business Executive.
- Retrieves relevant support knowledge using RAG.
- Generates a response in the matching style.
- Escalates sensitive or low-confidence queries.

## Setup
1. Create a virtual environment.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Copy `.env.example` to `.env` and add your Gemini API key.
4. Run:
   ```bash
   streamlit run app.py
   ```

## Data folder
Add more `.txt`, `.md`, or `.pdf` support articles into `data/` and click **Index / Rebuild Knowledge Base**.
