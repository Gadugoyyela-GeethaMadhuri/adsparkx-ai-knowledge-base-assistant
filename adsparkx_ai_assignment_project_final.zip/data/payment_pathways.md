# Payment Pathways

Supported payment methods include cards and bank transfers depending on account region. For failed payments, verify account limits, card expiry, and bank authorization status. Retry once after 15 minutes and escalate if repeated failures occur.