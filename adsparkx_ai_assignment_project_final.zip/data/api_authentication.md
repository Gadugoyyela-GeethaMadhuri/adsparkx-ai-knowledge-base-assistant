# API Authentication

Use a bearer token in the Authorization header.

Example:
`Authorization: Bearer <ACCESS_TOKEN>`

Tokens expire every 24 hours. If authentication fails, ensure the token is not malformed, has no trailing spaces, and that the environment variable is set correctly.