# Security Policy

Never expose secrets, tokens, passwords, or private keys in responses. If a query involves account modification, refund requests, or legal concerns, trigger escalation and create a structured handoff summary.