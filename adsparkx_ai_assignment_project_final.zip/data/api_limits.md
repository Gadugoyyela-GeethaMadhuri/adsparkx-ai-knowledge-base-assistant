# API Limits

Rate limits may apply. Use retry with exponential backoff for transient failures. Preserve request IDs in logs and advise users to retry after a short cooldown.